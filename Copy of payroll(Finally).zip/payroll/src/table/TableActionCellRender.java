
package table;
import java.awt.Color;
import java.awt.Component;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;


public class TableActionCellRender extends DefaultTableCellRenderer {
    @Override
    public Component getTableCellRendererComponent(JTable jtable, Object a, boolean isSelected, boolean bn1, int x, int y){
        Component com = super.getTableCellRendererComponent(jtable, a, isSelected, bn1, x, y);
        
        PanelAction action = new PanelAction();
        if(isSelected == false&& x % 2 == 0){
            action.setBackground(new Color(38, 94, 124));
        }
        else{
            action.setBackground(com.getBackground());
        }
        return action;
    }
}
