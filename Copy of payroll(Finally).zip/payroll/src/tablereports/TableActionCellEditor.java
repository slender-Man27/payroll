
package tablereports;
import java.awt.Color;
import java.awt.Component;
import javax.swing.DefaultCellEditor; 
import javax.swing.JCheckBox;
import javax.swing.JTable;


public class TableActionCellEditor extends DefaultCellEditor{
    
    private TableActionEvent event;
    
    public TableActionCellEditor(TableActionEvent event){
        super(new JCheckBox());
        this.event = event;
    }
    
    @Override
    public Component getTableCellEditorComponent(JTable jtable, Object a, boolean bn, int x, int y){
        PanelAction action = new PanelAction();
        action.initEvent(event, x);
        action.setBackground(jtable.getSelectionBackground());
        return action;
    }
}
