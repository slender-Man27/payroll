
package tablereports;

public interface TableActionEvent {
    
    public void onEdit(int r);
    
    public void onDelete(int r);
    
    public void onView(int r);
}
