package payroll;

import java.sql.*;

import javax.swing.table.DefaultTableModel;
public class DeductionsDataRetrieve {
    
    
    public static void fetchDataIntoDeductionLinkedList(Connection connection, DeductionsLinked linkedList, DefaultTableModel model) throws SQLException {
        Statement statement = connection.createStatement();
        String query = "SELECT * FROM deductions";
        ResultSet resultSet = statement.executeQuery(query);

        while (resultSet.next()) {

            String deducName = resultSet.getString("deduction_description");
            double deducRate = resultSet.getDouble("rate");
            String deducStatus= resultSet.getString("deduction_status");
            
            linkedList.addDeducNode(deducName, deducRate, deducStatus, model);
        }
    }
}